#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

// Mock NTPtap library function
// Returns 0 on success, non-zero error code on failure
int NTPtap_time_check() {
    // Simulate NTP time check
    // In a real implementation, this would connect to NTP servers
    static int call_count = 0;
    call_count++;
    
    // Simulate occasional failures for demonstration
    if (call_count % 10 == 0) {
        return -1; // Error code
    }
    return 0; // Success
}

// Data source functions
float datasource1() {
    // Simulate temperature sensor
    return 23.5 + (rand() % 100) / 10.0;
}

float datasource2() {
    // Simulate humidity sensor
    return 45.0 + (rand() % 400) / 10.0;
}

float datasource3() {
    // Simulate pressure sensor
    return 1013.25 + (rand() % 200 - 100) / 10.0;
}

void display_dashboard() {
    float value1 = datasource1();
    float value2 = datasource2();
    float value3 = datasource3();
    
    time_t now;
    time(&now);
    
    printf("\n=== Dashboard Display ===\n");
    printf("Last updated: %s", ctime(&now));
    printf("Temperature: %.1f°C\n", value1);
    printf("Humidity: %.1f%%\n", value2);
    printf("Pressure: %.2f hPa\n", value3);
    printf("========================\n");
}

void shutdown_device() {
    printf("ERROR: NTP time check failed. Shutting down device for security.\n");
    exit(1);
}

int main() {
    printf("Dashboard Firmware v1.0 Starting...\n");
    
    // Startup NTP time check
    printf("Performing NTP time check...\n");
    if (NTPtap_time_check() != 0) {
        shutdown_device();
        return 1;
    }
    printf("NTP time check successful.\n");
    
    // Initialize random seed for data sources
    srand(time(NULL));
    
    printf("Dashboard initialized successfully.\n");
    printf("Refreshing every 60 seconds. Press Ctrl+C to stop.\n");
    
    // Main loop - refresh every minute (60 seconds)
    while (1) {
        display_dashboard();
        
        // Sleep for 60 seconds (1 minute refresh rate)
        sleep(60);
        
        // Periodic NTP check (every 10 minutes for security)
        static int cycle_count = 0;
        cycle_count++;
        if (cycle_count % 10 == 0) {
            printf("Performing periodic NTP time check...\n");
            if (NTPtap_time_check() != 0) {
                shutdown_device();
                return 1;
            }
        }
    }
    
    return 0;
}