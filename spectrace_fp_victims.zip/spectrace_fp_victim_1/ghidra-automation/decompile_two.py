#!/usr/bin/env python3
import os, sys, subprocess
from dotenv import load_dotenv

# Load env vars from .env
load_dotenv()

GHIDRA_HEADLESS = os.getenv("GHIDRA_HEADLESS")
OUTPUT_DIR = os.getenv("OUTPUT_DIR")
EXPORT_SCRIPT = os.path.join(os.path.dirname(__file__), "export-decompile.py")

if not GHIDRA_HEADLESS or not os.path.isfile(GHIDRA_HEADLESS):
    sys.exit("[-] GHIDRA_HEADLESS not set or invalid. Check .env")
if not OUTPUT_DIR:
    sys.exit("[-] OUTPUT_DIR not set. Check .env")

os.makedirs(OUTPUT_DIR, exist_ok=True)

def run_decompile(binary, idx):
    projdir = os.path.join(OUTPUT_DIR, f"proj{idx}")
    projname = f"proj{idx}"
    
    # Create the project directory
    os.makedirs(projdir, exist_ok=True)
    
    cmd = [
        GHIDRA_HEADLESS,
        projdir,
        projname,
        "-import", os.path.abspath(binary),
        "-scriptPath", os.path.dirname(EXPORT_SCRIPT),
        "-postScript", os.path.basename(EXPORT_SCRIPT), os.path.abspath(OUTPUT_DIR),
        "-deleteProject"
    ]
    print(f"[+] Running Ghidra on {binary} ...")
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    # Check if output files were created (Ghidra sometimes returns exit code 1 even on success)
    binary_name = os.path.basename(binary)
    expected_asm = os.path.join(OUTPUT_DIR, f"{binary_name}_asm.txt")
    expected_c = os.path.join(OUTPUT_DIR, f"{binary_name}_c.c")
    
    if os.path.exists(expected_asm) and os.path.exists(expected_c):
        print(f"[✓] Successfully decompiled {binary}")
    else:
        print(f"[!] Ghidra failed for {binary}")
        print("STDOUT:", result.stdout)
        print("STDERR:", result.stderr)
        sys.exit(1)

def decompile_two_binaries(bin1, bin2):
    run_decompile(bin1, 1)
    run_decompile(bin2, 2)
    print("[✓] Done. Check outputs in:", OUTPUT_DIR)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <binary1> <binary2>")
        sys.exit(1)
    decompile_two_binaries(sys.argv[1], sys.argv[2])