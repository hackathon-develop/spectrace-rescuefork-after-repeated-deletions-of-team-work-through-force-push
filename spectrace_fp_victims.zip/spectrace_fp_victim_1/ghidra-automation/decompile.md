# Ghidra Dual Binary Decompiler (Headless)

Automated headless decompilation of **two binaries** with Ghidra on macOS.  
This wrapper launches Ghidra headless, decompiles both binaries, and exports:

- **ASCII disassembly** (`*_asm.txt`)  
- **C-like pseudocode** (`*_c.c`)  

No GUI clicking required.

---

## 📦 Project Structure

```
.
├── .env                # Environment configuration
├── decompile_two.py    # Python driver (run this)
├── export_decompile.py # Ghidra Jython script (runs inside Ghidra)
└── README.md           # You are here
```

---

## ⚙️ Requirements

- **macOS**  
- **Python 3**  
- **Ghidra 11.4.2 (or newer)** downloaded and unzipped  
- Python package: [python-dotenv](https://pypi.org/project/python-dotenv/)

Install `python-dotenv` once:

```bash
pip install python-dotenv
```

---

## 🔧 Setup

### 1. Download and unzip Ghidra

Example location:
```
/Users/<you>/Downloads/ghidra_11.4.2_PUBLIC
```

### 2. Place project files together

Put `decompile_two.py`, `export_decompile.py`, and `.env` in the same folder.

### 3. Edit .env

Example contents:
```bash
GHIDRA_HEADLESS=/Users/<you>/Downloads/ghidra_11.4.2_PUBLIC/support/analyzeHeadless
OUTPUT_DIR=/Users/<you>/ghidra-out
```

- `GHIDRA_HEADLESS` → full path to `analyzeHeadless` inside Ghidra.
- `OUTPUT_DIR` → folder where results will be saved.

### 4. Create output folder

```bash
mkdir -p ~/ghidra-out
```

---

## 🚀 Usage

Run the driver script with two binaries:

```bash
python3 decompile_two.py firmware1.bin firmware2.bin
```

This will:
- Import both binaries into temporary Ghidra projects
- Export each to ASCII + C pseudocode
- Save results in `OUTPUT_DIR`

---

## 📂 Output

For two binaries (`firmware1.bin` and `firmware2.bin`) you will get:

```
~/ghidra-out/
├── firmware1.bin_asm.txt
├── firmware1.bin_c.txt
├── firmware2.bin_asm.txt
└── firmware2.bin_c.txt
```

- `*_asm.txt` → raw disassembly of functions
- `*_c.txt` → decompiled pseudocode (C/C++)

---

## 🧪 Testing Setup

Check Ghidra headless:
```bash
/Users/<you>/Downloads/ghidra_11.4.2_PUBLIC/support/analyzeHeadless
```

Expected: a usage/help message appears.

Quick no-op project test:
```bash
/Users/<you>/Downloads/ghidra_11.4.2_PUBLIC/support/analyzeHeadless /tmp/test_proj proj1 -deleteProject
```

---

## ⚠️ Notes

- Ghidra headless can take a while on large binaries.
- Decompiled output is best-effort pseudocode, not guaranteed valid C/C++.
- macOS may block downloaded binaries. If needed, unquarantine Ghidra:

```bash
xattr -dr com.apple.quarantine /Users/<you>/Downloads/ghidra_11.4.2_PUBLIC
```

This is ready to save as `README.md` and will render cleanly on GitHub or any Markdown viewer.