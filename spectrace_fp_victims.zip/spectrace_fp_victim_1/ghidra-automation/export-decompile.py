# export_decompile.py
# This runs INSIDE Ghidra headless
# Args: [0] = output directory

from ghidra.app.decompiler import DecompInterface
from ghidra.util.task import ConsoleTaskMonitor
import os

def dump_decompiled(program, outdir):
    name = program.getName()
    safe = name.replace("/", "_").replace("\\", "_")
    base = os.path.join(outdir, safe)
    asm_path = base + "_asm.txt"
    c_path = base + "_c.c"

    fm = program.getFunctionManager()
    funcs = list(fm.getFunctions(True))
    listing = currentProgram.getListing()

    # Dump ASCII disassembly
    with open(asm_path, "w") as f:
        for func in funcs:
            f.write("----- {} @ {} -----\n".format(func.getName(), func.getEntryPoint()))
            ins_iter = listing.getInstructions(func.getBody(), True)
            for ins in ins_iter:
                f.write("{}: {}\n".format(ins.getAddress(), ins))

    # Dump decompiled C
    ifc = DecompInterface()
    ifc.openProgram(program)
    with open(c_path, "w") as f:
        for func in funcs:
            res = ifc.decompileFunction(func, 30, ConsoleTaskMonitor())
            if res and res.getDecompiledFunction():
                f.write("/* {} */\n".format(func.getName()))
                f.write(res.getDecompiledFunction().getC())
                f.write("\n\n")

    print("[+] Decompiled {} -> {}, {}".format(name, asm_path, c_path))

dump_decompiled(currentProgram, getScriptArgs()[0])